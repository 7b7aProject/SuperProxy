package com.github.steveice10.mc.protocol.data.game;

public enum ClientRequest {
    RESPAWN,
    STATS;
}
