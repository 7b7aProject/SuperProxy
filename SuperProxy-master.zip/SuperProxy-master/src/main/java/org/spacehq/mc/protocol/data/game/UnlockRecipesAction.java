package com.github.steveice10.mc.protocol.data.game;

public enum UnlockRecipesAction {
    INIT,
    ADD,
    REMOVE;
}
