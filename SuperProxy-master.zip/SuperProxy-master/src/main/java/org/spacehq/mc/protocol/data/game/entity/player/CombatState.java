package com.github.steveice10.mc.protocol.data.game.entity.player;

public enum CombatState {
    ENTER_COMBAT,
    END_COMBAT,
    ENTITY_DEAD;
}
