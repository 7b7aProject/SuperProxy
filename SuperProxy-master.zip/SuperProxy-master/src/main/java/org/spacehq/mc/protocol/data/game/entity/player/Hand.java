package com.github.steveice10.mc.protocol.data.game.entity.player;

public enum Hand {
    MAIN_HAND,
    OFF_HAND;
}
