package com.github.steveice10.mc.protocol.data.game.entity.player;

public enum InteractAction {
    INTERACT,
    ATTACK,
    INTERACT_AT;
}
