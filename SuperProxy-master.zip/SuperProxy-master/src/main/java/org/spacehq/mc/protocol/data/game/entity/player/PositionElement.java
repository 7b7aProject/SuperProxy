package com.github.steveice10.mc.protocol.data.game.entity.player;

public enum PositionElement {
    X,
    Y,
    Z,
    PITCH,
    YAW;
}
