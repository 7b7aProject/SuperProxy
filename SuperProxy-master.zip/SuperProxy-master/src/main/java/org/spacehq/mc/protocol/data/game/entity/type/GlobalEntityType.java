package com.github.steveice10.mc.protocol.data.game.entity.type;

public enum GlobalEntityType {
    LIGHTNING_BOLT;
}
