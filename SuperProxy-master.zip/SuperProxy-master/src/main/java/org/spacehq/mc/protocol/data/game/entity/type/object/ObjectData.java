package com.github.steveice10.mc.protocol.data.game.entity.type.object;

public interface ObjectData {
}
