package com.github.steveice10.mc.protocol.data.game.setting;

public enum ChatVisibility {
    FULL,
    SYSTEM,
    HIDDEN;
}
