package com.github.steveice10.mc.protocol.data.game.statistic;

public interface Statistic {
}
