package com.github.steveice10.mc.protocol.data.game.window;

public enum AdvancementTabAction {
    OPENED_TAB,
    CLOSED_SCREEN;
}
