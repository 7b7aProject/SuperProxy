package com.github.steveice10.mc.protocol.data.game.window;

public enum CraftingBookDataType {
    DISPLAYED_RECIPE,
    CRAFTING_BOOK_STATUS;
}
