package com.github.steveice10.mc.protocol.data.game.window;

public enum CreativeGrabParam implements WindowActionParam {
    GRAB;
}
