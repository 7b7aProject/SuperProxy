package com.github.steveice10.mc.protocol.data.game.window;

public enum FillStackParam implements WindowActionParam {
    FILL;
}
