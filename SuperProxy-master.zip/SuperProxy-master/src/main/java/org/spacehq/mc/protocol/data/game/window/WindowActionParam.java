package com.github.steveice10.mc.protocol.data.game.window;

public interface WindowActionParam {
}
