package com.github.steveice10.mc.protocol.data.game.window.property;

public interface WindowProperty {
}
