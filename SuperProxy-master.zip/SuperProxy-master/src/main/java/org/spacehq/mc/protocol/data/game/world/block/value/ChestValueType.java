package com.github.steveice10.mc.protocol.data.game.world.block.value;

public enum ChestValueType implements BlockValueType {
    VIEWING_PLAYER_COUNT;
}
