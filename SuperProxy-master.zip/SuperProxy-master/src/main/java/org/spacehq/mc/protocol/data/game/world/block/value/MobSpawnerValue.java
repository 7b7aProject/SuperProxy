package com.github.steveice10.mc.protocol.data.game.world.block.value;

public class MobSpawnerValue implements BlockValue {
}
