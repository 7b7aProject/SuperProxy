package com.github.steveice10.mc.protocol.data.game.world.block.value;

public enum MobSpawnerValueType implements BlockValueType {
    RESET_DELAY;
}
