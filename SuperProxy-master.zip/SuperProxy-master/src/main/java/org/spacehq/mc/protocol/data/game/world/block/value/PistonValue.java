package com.github.steveice10.mc.protocol.data.game.world.block.value;

public enum PistonValue implements BlockValue {
    DOWN,
    UP,
    SOUTH,
    WEST,
    NORTH,
    EAST;
}
