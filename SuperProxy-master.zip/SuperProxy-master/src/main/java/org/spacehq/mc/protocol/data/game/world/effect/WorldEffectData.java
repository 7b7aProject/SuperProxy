package com.github.steveice10.mc.protocol.data.game.world.effect;

public interface WorldEffectData {
}
