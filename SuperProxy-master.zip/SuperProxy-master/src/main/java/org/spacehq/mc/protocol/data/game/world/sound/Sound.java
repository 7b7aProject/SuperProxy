package com.github.steveice10.mc.protocol.data.game.world.sound;

public interface Sound {
}
