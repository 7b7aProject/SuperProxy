package com.github.steveice10.mc.protocol.data.handshake;

public enum HandshakeIntent {
    STATUS,
    LOGIN;
}
