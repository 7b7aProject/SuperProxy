// 
// Decompiled by Procyon v0.5.30
// 

package org.spacehq.packetlib.event.session;

public class SessionAdapter implements SessionListener {

  @Override
  public void packetReceived(final PacketReceivedEvent event) {
  }

  @Override
  public void packetSent(final PacketSentEvent event) {
  }

  @Override
  public void connected(final ConnectedEvent event) {
  }

  @Override
  public void disconnecting(final DisconnectingEvent event) {
  }

  @Override
  public void disconnected(final DisconnectedEvent event) {
  }
}
