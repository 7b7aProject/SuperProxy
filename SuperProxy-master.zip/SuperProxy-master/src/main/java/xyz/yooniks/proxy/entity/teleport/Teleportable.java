package xyz.yooniks.proxy.entity.teleport;

public interface Teleportable {

  void teleport(Location location);

}
